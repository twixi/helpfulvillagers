/*   */ package mods.helpfulvillagers.enums;
/*   */ 
/*   */ public enum EnumActivity {
/* 4 */   GATHER,
/* 5 */   RETURN,
/* 6 */   CRAFT,
/* 7 */   STORE,
/* 8 */   IDLE,
/* 9 */   FOLLOW;
/*   */ }


/* Location:              D:\Users\Joseph\Downloads\helpfulvillagers-1.7.10-1.4.0b5.jar!\mods\helpfulvillagers\enums\EnumActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */