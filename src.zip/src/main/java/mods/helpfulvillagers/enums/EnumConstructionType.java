/*   */ package mods.helpfulvillagers.enums;
/*   */ 
/*   */ public enum EnumConstructionType {
/* 4 */   DEMOLISH,
/* 5 */   RECORD,
/* 6 */   CONSTRUCT;
/*   */ }


/* Location:              D:\Users\Joseph\Downloads\helpfulvillagers-1.7.10-1.4.0b5.jar!\mods\helpfulvillagers\enums\EnumConstructionType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */